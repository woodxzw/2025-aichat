import React, { useMemo } from 'react';
import { FileIcon, LoaderIcon, MessageIcon, PencilEditIcon } from '../icons';
import s from './document-csv.module.css';
import ChartBar from './chart-bar';
import ChartPie from './chart-pie';
interface ColumnProps {
  result: [];
}
const renderNumberType = (index: number, group: any, min: number, max: number) => (
  <td className="w-full h-full flex flex-col" key={index}>
    <div className={s.c_chat_bar_l}>
      <ChartBar data={group} />
    </div>
    <div className={`${s.c_chat_b} mt-1`}>
      <span>{min}</span>
      <span>{max}</span>
    </div>
  </td>
);

const renderEnumType = (index: number, enums: any[]) => (
  <td className={`w-full h-full flex-col flex justify-evenly`} key={index}>
    {enums?.map(enmuItem => (
      <div key={enmuItem?.key} className="flex justify-between">
        <span>{enmuItem.key}</span>
        <span>{enmuItem.value}</span>
      </div>
    ))}
  </td>
);

const renderBoolType = (index: number, enums: any[], dataColumn: any) => (
  <td className={`w-full h-full flex items-center`} key={index}>
    <div className={s.c_chat_pie_l}>
      <ChartPie data={enums} />
    </div>
    <div className="flex-none ml-1" style={{ width: "90px" }}>
      {enums?.map(enmuItem => (
        <div key={enmuItem?.key}>
          <p>{enmuItem.key}</p>
          <div className="flex justify-between">
            <span>{enmuItem.value}</span>
            <span>{Math.round(enmuItem.value / dataColumn?.totalCount * 100)} %</span>
          </div>
        </div>
      ))}
    </div>
  </td>
);


const renderNumberCa = (mean: number, staDeviation: number, minimumFinite: number, quantiles: any[], maximumFinite: number) => (
  <>
    <div className='flex justify-between mb-1 text-xs'>
      <div className='flex-auto'>
        <span>Mean</span>
      </div>
      <div className='w-20'>{mean}</div>
      <div className={`w-12 ${s.c_color_gray}`}></div>
    </div>

    <div className='flex justify-between mb-3 text-xs'>
      <div className='flex-auto'>
        <span>Std. Deviation</span>
      </div>
      <div className='w-20'>{staDeviation}</div>
      <div className={`w-12 ${s.c_color_gray}`}></div>
    </div>

    <div className='flex justify-between mb-1 text-xs'>
      <div className='flex-auto'>
        <span>Quantiles</span>
      </div>
      <div className='w-20'>{minimumFinite}</div>
      <div className={`w-12 ${s.c_color_gray}`}>Min</div>
    </div>
    {
      quantiles?.map((quantil, quantilInd) => {
        return (
          <div className='flex justify-between mb-1 text-xs' key={quantilInd}>
            <div className='flex-auto'>
              <span></span>
            </div>
            <div className='w-20'>{quantil?.value}</div>
            <div className={`w-12 ${s.c_color_gray}`}>{quantil?.point * 100}%</div>
          </div>
        )
      })
    }
    <div className='flex justify-between mb-1 text-xs'>
      <div className='flex-auto'>
        <span></span>
      </div>
      <div className='w-20'>{maximumFinite}</div>
      <div className={`w-12 ${s.c_color_gray}`}>100%</div>
    </div>
  </>
)

const renderEnumCa = (uniqueValueCount:number,mostCommonValue:string,totalCount:number,mostCommonValueCount:number) => (
  <>
    <div className='flex justify-between mb-1 text-xs'>
      <div className='flex-auto'>
        <span>Unique</span>
      </div>
      <div className='w-20'>{uniqueValueCount}</div>
      <div className={`w-12 ${s.c_color_gray}`}></div>
    </div>

    <div className='flex justify-between mb-1 text-xs'>
      <div className='flex-auto'>
        <span>Most Common</span>
      </div>
      <div className='w-20'>{mostCommonValue}</div>
      <div className={`w-12 ${s.c_color_gray}`}>{Math.round(mostCommonValueCount / totalCount * 100)}%</div>
    </div>
  </>
)

const renderBoolCa = (enums:any[],totalCount:number) => (
  <>
    {
      enums?.map((item, ind) => {
        return (
          <div className='flex justify-between mb-1 text-xs' key={ind}>
            <div className='flex-auto'>
              <span>{item?.key}</span>
            </div>
            <div className='w-20'>{item?.value}</div>
            <div className={`w-12 ${s.c_color_gray}`}>{Math.round(item?.value / totalCount * 100)}%</div>
          </div>
        )
      })
    }
  </>
)


const Column: React.FC<ColumnProps> = ({ result }) => {
  // 接收到的数据
  const { dataTableHead } = useMemo(() => {
    return result || {}
  }, [result])
  return (
    <div className="flex flex-col w-full p-5" style={{ border: `1px solid rgb(218, 220, 224)` }}>
      {
        dataTableHead?.map((item, index) => {
          const { type, group, enums, dataColumn, min, max } = item || {};
          const {
            totalCount,
            validCount,
            missingCount,
            mismatchedCount,
            maximumFinite,
            mostCommonValue,
            mostCommonValueCount,
            uniqueValueCount,
            mean,
            minimumFinite,
            staDeviation,
            quantiles
          } = dataColumn || {}
          const safeQuantiles = Array.isArray(quantiles) ? quantiles : [];
          return (
            <div className={`flex flex-col w-full pb-3 mb-3 ${s.c_colunm_item_wrap}`} key={index}>
              <div className="font-bold text-lg flex items-center">
                <FileIcon />
                <div>{item?.name}</div>
              </div>
              <div className="mt-1">
                {item?.description}
              </div>
              <div className={`w-full grid ${s.c_colunm_item}`}>
                <div className="w-full h-full">
                  {type === 'number' && renderNumberType(index, group, min, max)}
                  {type === 'enum' && renderEnumType(index, enums)}
                  {type === 'bool' && renderBoolType(index, enums, dataColumn)}

                </div>
                <div className='w-full h-full'>
                  <div className="w-full flex mb-2">
                    <div className={`${s.progress} ${s.valid}`} style={{ width: `${Math.round(validCount / totalCount * 100)}%` }}></div>
                    <div className={`${s.progress} ${s.mismatched}`} style={{ width: `${Math.round(mismatchedCount / totalCount * 100)}%` }}></div>
                    <div className={`${s.progress} ${s.missing}`} style={{ width: `${Math.round(missingCount / totalCount * 100)}%` }}></div>
                  </div>
                  <div className='flex justify-between mb-1 text-xs'>
                    <div className='flex-auto'>
                      <span>Valid</span>
                      <span className={`w-2 h-2 ${s.valid} inline-block`}></span>
                    </div>
                    <div className='w-20'>{validCount}</div>
                    <div className={`w-12 ${s.c_color_gray}`}>{Math.round(validCount / totalCount * 100)}%</div>
                  </div>
                  <div className='flex justify-between mb-1 text-xs'>
                    <div className='flex-auto'>
                      <span>Mismatched</span>
                      <span className={`w-2 h-2 ${s.mismatched} inline-block`}></span>
                    </div>
                    <div className='w-20'>{mismatchedCount}</div>
                    <div className={`w-12 ${s.c_color_gray}`}>{Math.round(mismatchedCount / totalCount * 100)}%</div>
                  </div>
                  <div className='flex justify-between mb-1 text-xs'>
                    <div className='flex-auto'>
                      <span>Missing</span>
                      <span className={`w-2 h-2 ${s.missing} inline-block`}></span>
                    </div>
                    <div className='w-20'>{missingCount}</div>
                    <div className={`w-12 ${s.c_color_gray}`}>{Math.round(missingCount / totalCount * 100)}%</div>
                  </div>

                  {type === 'number' && renderNumberCa(mean, staDeviation, minimumFinite, quantiles, maximumFinite)}
                  {type === 'enum' && renderEnumCa(uniqueValueCount, mostCommonValue, totalCount, mostCommonValueCount)}
                  {type === 'bool' && renderBoolCa(enums, totalCount)}

                </div>
              </div>
            </div>
          )
        })
      }



    </div>
  )
}

export default Column;