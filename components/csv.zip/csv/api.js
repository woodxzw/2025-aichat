const getCsvData = async(params)=>{
    console.log(params);
    // TODO: csv sort & filter & enumerate
    // const response = await fetch(`/api/document?id=${block.documentId}`, {
    //     method: 'POST',
    //     body: JSON.stringify(params),
    // });
}

export {
    getCsvData
}