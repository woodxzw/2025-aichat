"use client";

import React, { useState, SetStateAction, useMemo } from 'react';
import { UIBlock } from '../block';
import { FileIcon, LoaderIcon, MessageIcon, PencilEditIcon } from '../icons';
import Detail from './detail';
import Compact from './compact';
import s from './document-csv.module.css';
import Column from './column';

const getActionText = (type: 'create' | 'update' | 'request-suggestions') => {
    switch (type) {
      case 'create':
        return 'Creating';
      case 'update':
        return 'Updating';
      case 'request-suggestions':
        return 'Adding suggestions';
      default:
        return null;
    }
};

// Tab组件
interface TabsProps {
  tabs: string[];
  activeTab: string;
  setActiveTab: (tab: string) => void;
}


function Tabs({ tabs, activeTab, setActiveTab }: TabsProps) {
  return (
    <div className={s.tabs}>
      {tabs.map((tab) => (
        <button
          key={tab}
          className={`${s.tab} ${activeTab === tab ? s.tab_active : ''}`}
          onClick={() => setActiveTab(tab)}
        >
          {tab}
        </button>
      ))}
    </div>
  );
}

// 表格数据接口
interface Data {
  personId: number;
  age: number;
  gender: string;
  undergradMajor: string;
  undergradGrade: number;
  yearsOfWork: number;
}

interface DocumentToolCsvResultProps {
    type: 'create' | 'update' | 'request-suggestions';
    result: any;
    block: UIBlock;
    setBlock: (value: SetStateAction<UIBlock>) => void;
}

// 主要组件
export function DocumentToolCsvResult({
    type,
    result,
    block,
    setBlock,
  }: DocumentToolCsvResultProps) {
  const [activeTab, setActiveTab] = useState<string>('Detail');
  const tabs = ['Detail', 'Compact', 'Column'];

  // 接收到的数据
  const {totolField,dataTableHead} = useMemo(()=>{
    return result || {}
  }, [result])

  return (
    <div className="container">
      {/* Tab导航 */}
      <div className={`flex justify-between ${s.border_bottom_1} pl-3`}>
        <Tabs tabs={tabs} activeTab={activeTab} setActiveTab={setActiveTab} />
        <div className='flex items-center'>
          <span className="mr-3">{dataTableHead?.length} of {totolField?.totolFieldAmount} colums</span>
          <LoaderIcon/>
        </div>
      </div>
      

      {/* 表格数据展示 */}
      <div className="tab-content">
        {activeTab === 'Detail' && (
          <Detail result={result} />
        )}

        {activeTab === 'Compact' && (
            <Compact result={result} />
        )}

        {activeTab === 'Column' && (
          <Column result={result} />
        )}
      </div>
    </div>
  );
}

interface DocumentToolCsvCallProps {
    type: 'create' | 'update' | 'request-suggestions';
    args: any;
  }
  
  export function DocumentToolCsvCall({ type, args }: DocumentToolCsvCallProps) {
    return (
      <div className="w-fit border py-2 px-3 rounded-xl flex flex-row items-start justify-between gap-3">
        <div className="flex flex-row gap-3 items-start">
          <div className="text-zinc-500 mt-1">
            {type === 'create' ? (
              <FileIcon />
            ) : type === 'update' ? (
              <PencilEditIcon />
            ) : type === 'request-suggestions' ? (
              <MessageIcon />
            ) : null}
          </div>
  
          <div className="">
            {getActionText(type)} {args.title}
          </div>
        </div>
  
        <div className="animate-spin mt-1">{<LoaderIcon />}</div>
      </div>
    );
  }
