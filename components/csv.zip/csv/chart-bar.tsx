import React, { useEffect, useRef } from 'react';
import * as echarts from 'echarts';

interface BarChartProps {
  data: [];
}

const ChartBar: React.FC<BarChartProps> = ({ data }) => {
  const chartRef = useRef<HTMLDivElement | null>(null);
  
  useEffect(() => {
    if (chartRef.current) {
      const myChart = echarts.init(chartRef.current);

      const option = {
        tooltip: {
          trigger: 'axis',
          formatter: (params: any) => {
            // 返回 tooltip 内容
            return `
              <div>
                <p style="font-size:10px">${data[params[0].dataIndex]?.label}</p>
                <p style="font-size:10px">Count: ${params[0].data}</p>
              </div>
            `;
          },
        },
        grid: {
          left: 0,
          right: 0,
          top: 0,
          bottom: 0,
          containLabel: false,
        },
        xAxis: {
          type: 'category',
          data: data.map(item => item.label),  // 使用原数据的label作为x轴
          axisLine: {
            show: false,
          },
          axisTick: {
            show: false,
          },
          axisLabel: {
            show: false,
          },
        },
        yAxis: {
          type: 'value',
          show: false,
          axisLine: {
            show: false,
          },
          axisTick: {
            show: false,
          },
          axisLabel: {
            show: false,
          },
        },
        series: [
          {
            data: data.map(item => item?.count),
            type: 'bar',
            barWidth: 'auto',
            itemStyle: {
              normal: {
                color: '#007BA8'
              }
            },
            barGap: 1, // 柱子之间的间隔为 0
            barCategoryGap: 0 // 柱子与分类之间的间隔为 0
          }
        ],
      };

      myChart.setOption(option);

      return () => {
        myChart.dispose();
      };
    }
  }, [data]);

  return (
    <div ref={chartRef} style={{ width: '100%', height: '100%' }}></div>
  );
};

export default ChartBar;